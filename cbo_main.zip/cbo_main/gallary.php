<?php
// Directory to store uploaded images
$uploadDir = 'uploads/';

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $fileName = basename($_FILES['image']['name']);
    $targetFile = $uploadDir . $fileName;

    // Check if the file is an image
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileType, $allowedTypes)) {
        // Move file to the uploads directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            echo "<p style='color: green;'>Image uploaded successfully!</p>";
        } else {
            echo "<p style='color: red;'>Error uploading image.</p>";
        }
    } else {
        echo "<p style='color: red;'>Invalid file type. Only JPG, PNG, and GIF are allowed.</p>";
    }
}

// Get all images from the uploads directory
$images = array_diff(scandir($uploadDir), ['.', '..']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Gallery</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Photo Gallery</h1>

    <!-- Image Upload Form -->
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="image">Upload an image:</label>
        <input type="file" name="image" id="image" required>
        <button type="submit">Upload</button>
    </form>

    <!-- Display Gallery -->
    <div class="gallery">
        <?php foreach ($images as $image): ?>
            <div class="gallery-item">
                <img src="<?= $uploadDir . $image ?>" alt="Gallery Image">
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
